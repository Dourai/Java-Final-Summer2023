import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class TimePunch extends Application {
    private TimeIn timeIn;
    private BreakTime breakTime;
    private TimeOut timeOut;
    private EmpInfo empInfo;
    
    public static void main(String[] args) {
    	
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        timeIn = new TimeIn();
        breakTime = new BreakTime();
        timeOut = new TimeOut();
        empInfo = new EmpInfo();
        
        primaryStage.setTitle("Time Punch Clock");

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10));
        grid.setVgap(10);
        grid.setHgap(10);
        // ... (Adding labels, text fields, and buttons to the grid)

        Scene scene = new Scene(grid, 300, 300);
       
        primaryStage.setScene(scene);
        primaryStage.show();
    

        Label nameLabel = new Label("Name:");
        TextField nameField = new TextField();

        Label wageLabel = new Label("Hourly Wage:");
        TextField wageField = new TextField();

        Label positionLabel = new Label("Position:");
        TextField positionField = new TextField();

        Label clockLabel = new Label("Clock:");

        Button clockInButton = new Button("Clock In");
        clockInButton.setOnAction(event -> clockIn());

        Button breakButton = new Button("Clock Out for Break");
        breakButton.setOnAction(event -> clockOutForBreak());

        Button clockOutButton = new Button("Clock Out");
        clockOutButton.setOnAction(event -> clockOut());

        Button calculatePayButton = new Button("Calculate Pay");
        calculatePayButton.setOnAction(event -> calculatePay());

        grid.add(nameLabel, 0, 0);
        grid.add(nameField, 1, 0);
        grid.add(wageLabel, 0, 1);
        grid.add(wageField, 1, 1);
        grid.add(positionLabel, 0, 2);
        grid.add(positionField, 1, 2);
        grid.add(clockLabel, 0, 3);
        grid.add(clockInButton, 0, 4);
        grid.add(breakButton, 0, 5);
        grid.add(clockOutButton, 0, 6);
        grid.add(calculatePayButton, 0, 7);


        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void clockIn() {
        timeIn.clockIn();
    }

    private void clockOutForBreak() {
        breakTime.clockOutForBreak();
    }

    private void clockOut() {
        timeOut.clockOut();
    }

    private void calculatePay() {
        double hoursWorked = timeOut.getHoursWorked(timeIn);
        double grossPay = empInfo.calculateGrossPay(hoursWorked);
        double taxAmount = empInfo.calculateTaxAmount(grossPay);
        double hourlyWage = empInfo.getHourlyWage();
        grossPay = hoursWorked * hourlyWage;
        taxAmount = grossPay * 0.032;
        System.out.println("Hours Worked: " + hoursWorked);
        System.out.println("Gross Pay: $" + grossPay);
        System.out.println("Tax Amount: $" + taxAmount);

        String name = empInfo.getName();
        double hoursWorkedThisWeek = empInfo.getHoursWorkedThisWeek();
        String position = empInfo.getPosition();

        System.out.println("Name: " + name);
        System.out.println("Hourly Wage: $" + hourlyWage);
        System.out.println("Hours Worked This Week: " + hoursWorkedThisWeek);
        System.out.println("Position: " + position);
    }
}



