import java.time.LocalDateTime;

public class BreakTime extends TimeEvent {
    private LocalDateTime expectedBackTime;

    public void clockOutForBreak() {
        eventTime = LocalDateTime.now();
        expectedBackTime = eventTime.plusMinutes(30);
        System.out.println("Clock Out for Break Time: " + eventTime);
        System.out.println("Expected Back Time: " + expectedBackTime);
    }

    public LocalDateTime getExpectedBackTime() {
        return expectedBackTime;
    }
}

