import java.time.LocalDateTime;

public class TimeIn extends TimeEvent {
    public void clockIn() {
        eventTime = LocalDateTime.now();
        System.out.println("Clock In Time: " + eventTime);
    }
}

