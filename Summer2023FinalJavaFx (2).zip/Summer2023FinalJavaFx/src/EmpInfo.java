
public class EmpInfo {
    private String name;
    private double hourlyWage;
    private double hoursWorkedThisWeek;
    private String position;

    public String getName() {
        return name;
    }

    public double getHourlyWage() {
        return hourlyWage;
    }

    public double getHoursWorkedThisWeek() {
        return hoursWorkedThisWeek;
    }

    public String getPosition() {
        return position;
    }

    public double calculateGrossPay(double hoursWorked) {
        return hoursWorked * hourlyWage;
    }

    public double calculateTaxAmount(double grossPay) {
        // Calculation logic for tax amount
        return grossPay * 0.2; // Sample tax calculation
    }
}

