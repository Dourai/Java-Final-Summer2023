import java.time.Duration;
import java.time.LocalDateTime;

public class TimeOut extends TimeEvent {
    public void clockOut() {
        eventTime = LocalDateTime.now();
        System.out.println("Clock Out Time: " + eventTime);
    }

    public double getHoursWorked(TimeIn timeIn) {
        LocalDateTime clockInTime = timeIn.getEventTime();
        Duration duration = Duration.between(clockInTime, eventTime);
        return duration.toHours();
    }
}

