import java.time.LocalDateTime;

public abstract class TimeEvent {
    protected LocalDateTime eventTime;

    public LocalDateTime getEventTime() {
        return eventTime;
    }
}

